
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","AnnotatedTimeLine"],["c","AreaChart"],["f","array_is_multi()"],["f","array_string()"],["c","backgroundColor"],["c","chartArea"],["c","configOptions"],["c","DataCell"],["c","DataTable"],["c","description"],["c","Exception"],["c","Gcharts"],["c","hAxis"],["c","jsDate"],["c","legend"],["c","LineChart"],["c","PieChart"],["c","textStyle"],["c","tooltip"],["f","valid_int()"]];
